/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package busreservation;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 *
 * @author Sumanth
 */
@Entity
@Table(name = "employee_details", catalog = "busm", schema = "")
@NamedQueries({
    @NamedQuery(name = "EmployeeDetails_1.findAll", query = "SELECT e FROM EmployeeDetails_1 e"),
    @NamedQuery(name = "EmployeeDetails_1.findByEntry", query = "SELECT e FROM EmployeeDetails_1 e WHERE e.entry = :entry"),
    @NamedQuery(name = "EmployeeDetails_1.findByName", query = "SELECT e FROM EmployeeDetails_1 e WHERE e.name = :name"),
    @NamedQuery(name = "EmployeeDetails_1.findById", query = "SELECT e FROM EmployeeDetails_1 e WHERE e.id = :id"),
    @NamedQuery(name = "EmployeeDetails_1.findByPhoneNo", query = "SELECT e FROM EmployeeDetails_1 e WHERE e.phoneNo = :phoneNo"),
    @NamedQuery(name = "EmployeeDetails_1.findByEmailid", query = "SELECT e FROM EmployeeDetails_1 e WHERE e.emailid = :emailid")})
public class EmployeeDetails_1 implements Serializable {
    @Transient
    private PropertyChangeSupport changeSupport = new PropertyChangeSupport(this);
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "entry")
    private Integer entry;
    @Basic(optional = false)
    @Column(name = "name")
    private String name;
    @Basic(optional = false)
    @Column(name = "id")
    private String id;
    @Basic(optional = false)
    @Column(name = "phoneNo")
    private int phoneNo;
    @Basic(optional = false)
    @Column(name = "emailid")
    private String emailid;

    public EmployeeDetails_1() {
    }

    public EmployeeDetails_1(Integer entry) {
        this.entry = entry;
    }

    public EmployeeDetails_1(Integer entry, String name, String id, int phoneNo, String emailid) {
        this.entry = entry;
        this.name = name;
        this.id = id;
        this.phoneNo = phoneNo;
        this.emailid = emailid;
    }

    public Integer getEntry() {
        return entry;
    }

    public void setEntry(Integer entry) {
        Integer oldEntry = this.entry;
        this.entry = entry;
        changeSupport.firePropertyChange("entry", oldEntry, entry);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        String oldName = this.name;
        this.name = name;
        changeSupport.firePropertyChange("name", oldName, name);
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        String oldId = this.id;
        this.id = id;
        changeSupport.firePropertyChange("id", oldId, id);
    }

    public int getPhoneNo() {
        return phoneNo;
    }

    public void setPhoneNo(int phoneNo) {
        int oldPhoneNo = this.phoneNo;
        this.phoneNo = phoneNo;
        changeSupport.firePropertyChange("phoneNo", oldPhoneNo, phoneNo);
    }

    public String getEmailid() {
        return emailid;
    }

    public void setEmailid(String emailid) {
        String oldEmailid = this.emailid;
        this.emailid = emailid;
        changeSupport.firePropertyChange("emailid", oldEmailid, emailid);
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (entry != null ? entry.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof EmployeeDetails_1)) {
            return false;
        }
        EmployeeDetails_1 other = (EmployeeDetails_1) object;
        if ((this.entry == null && other.entry != null) || (this.entry != null && !this.entry.equals(other.entry))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "busreservation.EmployeeDetails_1[ entry=" + entry + " ]";
    }

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.removePropertyChangeListener(listener);
    }
    
}
