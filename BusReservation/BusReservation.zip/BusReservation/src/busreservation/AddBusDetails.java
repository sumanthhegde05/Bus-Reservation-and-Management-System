package busreservation;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.JSpinner;
import javax.swing.SpinnerDateModel;
import javax.swing.Timer;

public class AddBusDetails extends javax.swing.JInternalFrame {

    public AddBusDetails() {
        initComponents();
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        departDateDP.setFormats(format);
        Time();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        departDateDP = new org.jdesktop.swingx.JXDatePicker();
        busTF = new javax.swing.JTextField();
        sourceTF = new javax.swing.JTextField();
        destinationTF = new javax.swing.JTextField();
        priceTF = new javax.swing.JTextField();
        seatTF = new javax.swing.JTextField();
        moveCB = new javax.swing.JComboBox();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        Stime = new javax.swing.JLabel();
        Date date = new Date();
        SpinnerDateModel sm = new SpinnerDateModel(date, null, null, Calendar.HOUR_OF_DAY);
        timer = new javax.swing.JSpinner(sm);
        jLabel10 = new javax.swing.JLabel();

        setClosable(true);
        setIconifiable(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(215, 215, 255));
        jLabel1.setText("Bus No :");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 190, -1, -1));

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(215, 215, 255));
        jLabel2.setText("Type :");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(399, 186, -1, -1));

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(215, 215, 255));
        jLabel3.setText("Source :");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 260, -1, -1));

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(215, 215, 255));
        jLabel4.setText("Price :");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(399, 251, -1, -1));

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(215, 215, 255));
        jLabel5.setText("Destination :");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 310, -1, -1));

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(215, 215, 255));
        jLabel6.setText("Time :");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(399, 309, -1, -1));

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(215, 215, 255));
        jLabel7.setText("Date :");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 370, -1, -1));

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(215, 215, 255));
        jLabel8.setText("Seat :");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(399, 366, -1, -1));

        departDateDP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                departDateDPActionPerformed(evt);
            }
        });
        getContentPane().add(departDateDP, new org.netbeans.lib.awtextra.AbsoluteConstraints(221, 365, -1, -1));
        getContentPane().add(busTF, new org.netbeans.lib.awtextra.AbsoluteConstraints(221, 186, 125, -1));
        getContentPane().add(sourceTF, new org.netbeans.lib.awtextra.AbsoluteConstraints(221, 251, 125, -1));

        destinationTF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                destinationTFActionPerformed(evt);
            }
        });
        getContentPane().add(destinationTF, new org.netbeans.lib.awtextra.AbsoluteConstraints(221, 309, 125, -1));

        priceTF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                priceTFActionPerformed(evt);
            }
        });
        getContentPane().add(priceTF, new org.netbeans.lib.awtextra.AbsoluteConstraints(464, 251, 108, -1));
        getContentPane().add(seatTF, new org.netbeans.lib.awtextra.AbsoluteConstraints(464, 366, 108, -1));

        moveCB.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Mini", "normal", "tempo", "Double decker" }));
        moveCB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                moveCBActionPerformed(evt);
            }
        });
        getContentPane().add(moveCB, new org.netbeans.lib.awtextra.AbsoluteConstraints(464, 186, -1, -1));

        jButton1.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        jButton1.setText("Save");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 430, 90, 30));

        jButton2.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        jButton2.setText("Reset");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 430, 100, 30));

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 30)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(215, 215, 255));
        jLabel9.setText("Add New Bus");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 120, -1, -1));

        Stime.setText("  ");
        getContentPane().add(Stime, new org.netbeans.lib.awtextra.AbsoluteConstraints(244, 13, 65, -1));

        JSpinner.DateEditor de = new JSpinner.DateEditor(timer, "HH:mm:ss");
        timer.setEditor(de);
        getContentPane().add(timer, new org.netbeans.lib.awtextra.AbsoluteConstraints(464, 309, 108, -1));

        jLabel10.setIcon(new javax.swing.ImageIcon("C:\\Users\\Sumanth\\Desktop\\AddBusDetails.png")); // NOI18N
        jLabel10.setText("jLabel10");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -30, 780, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents
    public void infoMessage(String message, String tittle) {
        JOptionPane.showMessageDialog(null, message, tittle, JOptionPane.INFORMATION_MESSAGE);
    }
    private void priceTFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_priceTFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_priceTFActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed

        int a = 0, b = 0;
        String departDate = null;
        String busno = busTF.getText();
        String bustype = (String) moveCB.getSelectedItem();
        String source = sourceTF.getText();
        String destination = destinationTF.getText();
        java.util.Date departDateD = departDateDP.getDate();
        SimpleDateFormat oDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        departDate = oDateFormat.format(departDateD);
        String departTime = timer.getValue().toString() ; 
        String dtime = departTime.substring(11,19);
        String price = priceTF.getText();
        String k = Date();
        String j = Time();

        try 
        {
            a = Integer.parseInt(seatTF.getText());
            b = Integer.parseInt(priceTF.getText());
        } 
        catch (NumberFormatException s ) {
            infoMessage("Enter proper details", "Alert");
            return;
        }
        
        if(a<1 || b<1)
        {
         infoMessage("Enter proper details", "Alert");   
         return;
        }
        
        if ((busno.isEmpty()) || (bustype.isEmpty()) || (source.isEmpty()) || (destination.isEmpty()) || (departDate.isEmpty()) || (dtime.isEmpty()) || (price.isEmpty()) || (a == 0)) {
            infoMessage("Enter all the fields", "Alert");
            return;
        }
        else if (Integer.parseInt(departDate.substring(0 , 4)) < Integer.parseInt(k.substring(0, 4))) 
        {
         
         return;   
        }
        else if (Integer.parseInt(departDate.substring(0 , 4)) == Integer.parseInt(k.substring(0, 4)))
        {   
            if (Integer.parseInt(departDate.substring(5, 7)) < Integer.parseInt(k.substring(5, 7))) 
            {
                 infoMessage("Enter proper date", "Alert");
                 return;
            }
            else if  (Integer.parseInt(departDate.substring(5,7)) == Integer.parseInt(k.substring(5,7)))
            {
                  if (Integer.parseInt(departDate.substring(8, 10)) < Integer.parseInt(k.substring(8,10))) 
                  {
                    infoMessage("Enter proper date", "Alert");
                    return;  
                  }
                  else if (Integer.parseInt(departDate.substring(8, 10)) == Integer.parseInt(k.substring(8, 10))) 
                  {
                      if (Integer.parseInt(dtime.substring(0,2)) < Integer.parseInt(j.substring(0,2))) 
                      {
                          infoMessage("Enter proper time", "Alert");
                          return;
                      }
                      else if(Integer.parseInt(dtime.substring(0,2)) == Integer.parseInt(j.substring(0,2)))
                      {
                         if (Integer.parseInt(dtime.substring(3,5)) < Integer.parseInt(j.substring(3,5))) 
                         {
                            infoMessage("Enter proper time", "Alert");  
                            return;
                         }
                         else if (Integer.parseInt(dtime.substring(6,8)) <= Integer.parseInt(j.substring(6,8)))
                         {
                             infoMessage("Enter proper time", "Alert");
                             return;
                         }
                      }
                  }         
            }   
        }
        
            try {
                Class.forName("com.mysql.jdbc.Driver");
                String databaseURL = "jdbc:mysql://localhost:3306/busm";
                Connection con = DriverManager.getConnection(databaseURL, "root", "");
                Statement stat = con.createStatement();
                String selectQuery = "select * from bus_details where bus_no='" + busno + "'";
                ResultSet rs = stat.executeQuery(selectQuery);

                if (rs.next() == true) {
                    infoMessage("Already Bus Details is Added", "Create Fresh Entry !!");
                    clearFieldValue();
                } 
                else {
                    String insertQuery = "insert into bus_details values(null,'" + busno + "','" + bustype + "','" + source + "','" + destination + "','" + departDate + "','" + dtime + "','" + price + "','" + a + "')";
                    stat.executeUpdate(insertQuery);
                    String selectQuery1 = "select * from source_details where source='" + source + "'";
                    ResultSet ks = stat.executeQuery(selectQuery1);
                    if (ks.next() == false) {
                        String insertQuery1 = "insert into source_details values(null,'" + source + "')";
                        stat.executeUpdate(insertQuery1);
                    }
                    String selectQuery2 = "select * from destination_details where destination='" + destination + "'";
                    ResultSet ls = stat.executeQuery(selectQuery2);
                    if (ls.next() == false) {
                        String insertQuery2 = "insert into destination_details values(null,'" + destination + "')";
                        stat.executeUpdate(insertQuery2);
                    }
                    String selectQuery3 = "select * from type_details where type ='" + bustype + "'";
                    ResultSet ms = stat.executeQuery(selectQuery3);
                    if (ms.next() == false) {
                        String insertQuery3 = "insert into type_details values(null,'" + bustype + "')";
                        stat.executeUpdate(insertQuery3);
                    }
                    infoMessage("Bus Details is Added", "Great work !!");
                    clearFieldValue();
                }
            } 
            catch (Exception e) 
            {
           infoMessage("Server timed out", "Alert");
            }
    }//GEN-LAST:event_jButton1ActionPerformed
    
    String Date() {
        Date d = new Date();
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd");
        return f.format(d);
    }

    String Time() {
        new Timer(0, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Date d = new Date();
                SimpleDateFormat k = new SimpleDateFormat("HH:mm:ss");
                Stime.setText(k.format(d));
            }
        }).start();
        return Stime.getText();
    }

    private void departDateDPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_departDateDPActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_departDateDPActionPerformed

    private void moveCBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_moveCBActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_moveCBActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        clearFieldValue();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void destinationTFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_destinationTFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_destinationTFActionPerformed

    public void clearFieldValue() {
        busTF.setText("");
        sourceTF.setText("");
        destinationTF.setText("");
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Stime;
    private javax.swing.JTextField busTF;
    private org.jdesktop.swingx.JXDatePicker departDateDP;
    private javax.swing.JTextField destinationTF;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JComboBox moveCB;
    private javax.swing.JTextField priceTF;
    private javax.swing.JTextField seatTF;
    private javax.swing.JTextField sourceTF;
    private javax.swing.JSpinner timer;
    // End of variables declaration//GEN-END:variables
}
