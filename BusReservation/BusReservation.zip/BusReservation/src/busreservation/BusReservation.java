/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package busreservation;

/**
 *
 * @author Sumanth
 */
public class BusReservation {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     InterfaceScreen i1 = new InterfaceScreen();
     i1.setLocationRelativeTo(null);
     i1.setVisible(true);
    }
    
}
